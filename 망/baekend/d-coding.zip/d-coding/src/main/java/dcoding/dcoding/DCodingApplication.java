package dcoding.dcoding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DCodingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DCodingApplication.class, args);
	}

}
