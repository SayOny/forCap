package dcoding.dcoding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DCodingApplicationTests {

	@Test
	void contextLoads() {
	}

}
